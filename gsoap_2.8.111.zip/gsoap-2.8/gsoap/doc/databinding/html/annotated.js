var annotated =
[
    [ "_a__address_book", "class__a____address__book.html", "class__a____address__book" ],
    [ "a__address", "classa____address.html", "classa____address" ],
    [ "g", "classg.html", "classg" ],
    [ "Graph", "class_graph.html", "class_graph" ],
    [ "SOAP_ENV__Code", "struct_s_o_a_p___e_n_v_____code.html", "struct_s_o_a_p___e_n_v_____code" ],
    [ "SOAP_ENV__Detail", "struct_s_o_a_p___e_n_v_____detail.html", "struct_s_o_a_p___e_n_v_____detail" ],
    [ "SOAP_ENV__Fault", "struct_s_o_a_p___e_n_v_____fault.html", "struct_s_o_a_p___e_n_v_____fault" ],
    [ "SOAP_ENV__Header", "struct_s_o_a_p___e_n_v_____header.html", "struct_s_o_a_p___e_n_v_____header" ],
    [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____reason.html", "struct_s_o_a_p___e_n_v_____reason" ]
];