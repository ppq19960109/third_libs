var hierarchy =
[
    [ "Graph", null, [
      [ "g", "classg.html", null ]
    ] ]
];