var structsoap__dime =
[
    [ "begin", "structsoap__dime.html#a4fe0d524cff9e2e467487dba18dd61f8", null ],
    [ "end", "structsoap__dime.html#af4c0808ed995d085514cfc0962bb4565", null ],
    [ "list", "structsoap__dime.html#a478a23b3994a35d1c0945751106cb4f6", null ]
];