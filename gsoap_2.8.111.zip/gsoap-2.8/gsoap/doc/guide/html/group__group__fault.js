var group__group__fault =
[
    [ "SOAP_ENV__Fault", "struct_s_o_a_p___e_n_v_____fault.html", [
      [ "detail", "struct_s_o_a_p___e_n_v_____fault.html#af49c2a1926ebf4c865ddd444960b9adb", null ],
      [ "faultactor", "struct_s_o_a_p___e_n_v_____fault.html#ae4c53ce0884ec757d48c1f62a516edce", null ],
      [ "faultcode", "struct_s_o_a_p___e_n_v_____fault.html#ad800dbd32b302cc9e096e6c311df29de", null ],
      [ "faultstring", "struct_s_o_a_p___e_n_v_____fault.html#ac08b3725c7c6b2e9c636995e82876a9a", null ],
      [ "SOAP_ENV__Code", "struct_s_o_a_p___e_n_v_____fault.html#acec1784f16ffd14a69a92b92f0ddd15f", null ],
      [ "SOAP_ENV__Detail", "struct_s_o_a_p___e_n_v_____fault.html#a560e6fd07a6b2f51cef97aa12282c870", null ],
      [ "SOAP_ENV__Node", "struct_s_o_a_p___e_n_v_____fault.html#a07e508b520e8a1e2c8ba20acf1c2ddd9", null ],
      [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____fault.html#a921e9d8c41d62f32ab6d4d39a2e71bc9", null ],
      [ "SOAP_ENV__Role", "struct_s_o_a_p___e_n_v_____fault.html#a9048c64196658de472d57fb42fae5daa", null ]
    ] ],
    [ "SOAP_ENV__Code", "struct_s_o_a_p___e_n_v_____code.html", [
      [ "SOAP_ENV__Subcode", "struct_s_o_a_p___e_n_v_____code.html#a2d44ac860b79956cff26131fa68b4c5a", null ],
      [ "SOAP_ENV__Value", "struct_s_o_a_p___e_n_v_____code.html#a6285b1ed8b2cadc318d730f9715b2958", null ]
    ] ],
    [ "SOAP_ENV__Detail", "struct_s_o_a_p___e_n_v_____detail.html", [
      [ "__any", "struct_s_o_a_p___e_n_v_____detail.html#a261e42921673a28bd085a47d4ed65ce6", null ],
      [ "__type", "struct_s_o_a_p___e_n_v_____detail.html#ae21be5af0f3f6dc47f2dbf4e35e22300", null ],
      [ "fault", "struct_s_o_a_p___e_n_v_____detail.html#a159d344759c06f82eae1949aea10a1cf", null ]
    ] ],
    [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____reason.html", [
      [ "SOAP_ENV__Text", "struct_s_o_a_p___e_n_v_____reason.html#a4e7a5850ce6987bf6d15bf9fea780ecd", null ]
    ] ],
    [ "soap_fault", "group__group__fault.html#ga0fe8da8d6501355a199d59204ef1e330", null ],
    [ "soap_fault_detail", "group__group__fault.html#gaa713e4a2ad1af8304db9d048d96bcd10", null ],
    [ "soap_fault_string", "group__group__fault.html#gabba65cbc38ea589f5cb28463c1657107", null ],
    [ "soap_fault_subcode", "group__group__fault.html#ga950543b654e24e726c0e31b31f529fea", null ],
    [ "soap_faultdetail", "group__group__fault.html#ga5fe7e6de9462b3abc93cf134af69c888", null ],
    [ "soap_faultstring", "group__group__fault.html#ga092eb1dcfc6d3e8bbb79322d17e6fd0c", null ],
    [ "soap_faultsubcode", "group__group__fault.html#gabd29adf329b00619777f7fd1dfa17cfd", null ],
    [ "soap_print_fault", "group__group__fault.html#ga931a4ab6df2553b48a0c270f8a0a88af", null ],
    [ "soap_print_fault_location", "group__group__fault.html#gaa70822938e0f116d1d0020aff66cc795", null ],
    [ "soap_receiver_fault", "group__group__fault.html#ga91dc6bcc3c5f35e023b78a6f46a79ed6", null ],
    [ "soap_receiver_fault_subcode", "group__group__fault.html#gaa5544bc29083bb0b28cda5b4ad696d6a", null ],
    [ "soap_sender_fault", "group__group__fault.html#gac20c8569833053318196d898fe2566af", null ],
    [ "soap_sender_fault_subcode", "group__group__fault.html#gaf273fe8f08c8ddd558d509c45d7dc20d", null ],
    [ "soap_sprint_fault", "group__group__fault.html#gafc9d67060889f7243381299047f0e8e6", null ],
    [ "soap_stream_fault", "group__group__fault.html#gaab984763de3f5fdd4363aa62b4f250c2", null ],
    [ "soap_stream_fault_location", "group__group__fault.html#ga48129588ed481ab84698fa5cd84851a5", null ]
];